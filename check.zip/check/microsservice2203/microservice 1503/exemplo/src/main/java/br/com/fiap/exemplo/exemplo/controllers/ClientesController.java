package br.com.fiap.exemplo.exemplo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import br.com.fiap.exemplo.exemplo.models.Clientes;
import br.com.fiap.exemplo.exemplo.models.Produto;
import br.com.fiap.exemplo.exemplo.repositories.ClienteRepository;
import br.com.fiap.exemplo.exemplo.repositories.ProdutoRepository;
import br.com.fiap.exemplo.exemplo.models.Categoria;

@Controller
@RequestMapping("/cliente")
public class ClientesController {
	
	@Autowired
	private ClienteRepository clienteRepository;

	@GetMapping("")
	public ModelAndView get() {
		ModelAndView model = new ModelAndView("cliente/index");
		

		List<Clientes> listaClientes = clienteRepository.findAll();

		model.addObject("clientes", listaClientes);
		return model;
		
	}

	
	@GetMapping("/create")
	public String create() {
		return "cliente/create";
	}

	@PostMapping("/create")
	public String create(@ModelAttribute("cliente") Clientes objCliente) {
		// enviar para base de dados

		clienteRepository.save(objCliente);

		return "redirect:/cliente";
	}

	@GetMapping("/categoria")
	@ResponseBody
	public Categoria getCategoria() {
		Categoria categoria = new Categoria();
		categoria.setDescricao("masculino");
		categoria.setId(1);

		return categoria;
	}

	@GetMapping("/categoria")
	@ResponseBody
	public Categoria getCategoria2() {
		Categoria categoria2 = new Categoria();
		categoria2.setDescricao("feminino");
		categoria2.setId(2);

		return categoria2;
	}

	@GetMapping("/categoria")
	@ResponseBody
	public Categoria getCategoria3() {
		Categoria categoria3 = new Categoria();
		categoria3.setDescricao("unissex");
		categoria3.setId(3);

		return categoria3;
	}

}
