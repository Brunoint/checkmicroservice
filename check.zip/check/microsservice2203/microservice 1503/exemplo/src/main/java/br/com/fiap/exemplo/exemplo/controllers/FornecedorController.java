package br.com.fiap.exemplo.exemplo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import br.com.fiap.exemplo.exemplo.models.Categoria;
import br.com.fiap.exemplo.exemplo.models.Fornecedor;
import br.com.fiap.exemplo.exemplo.models.Produto;
import br.com.fiap.exemplo.exemplo.repositories.FornecedorRepository;

@Controller
@RequestMapping("/fornecedor")
public class FornecedorController {

	@Autowired
	private FornecedorRepository fornecedorRepository;
	
	@GetMapping("")
	public ModelAndView get() {
		ModelAndView model = new ModelAndView("fornecedor/index");
		

		List<Fornecedor> listaFornecedor = fornecedorRepository.findAll();

		model.addObject("fornecedor", listaFornecedor);
		return model;
		
	}
	
	@GetMapping("/create")
	public String create() {
		return "fornecedor/create";
	}
	
	@PostMapping("/create")
	public String create(@ModelAttribute("fornecedor") Fornecedor objFornecedor) {
		// enviar para base de dados

		fornecedorRepository.save(objFornecedor);

		return "redirect:/fornecedor";
	}
	
	@GetMapping("/categoria")
	@ResponseBody
	public Categoria getCategoria() {
		Categoria categoria = new Categoria();
		categoria.setDescricao("masculino");
		categoria.setId(1);

		return categoria;
	}

	@GetMapping("/categoria")
	@ResponseBody
	public Categoria getCategoria2() {
		Categoria categoria2 = new Categoria();
		categoria2.setDescricao("feminino");
		categoria2.setId(2);

		return categoria2;
	}

	@GetMapping("/categoria")
	@ResponseBody
	public Categoria getCategoria3() {
		Categoria categoria3 = new Categoria();
		categoria3.setDescricao("unissex");
		categoria3.setId(3);

		return categoria3;
	}
	
	
}
